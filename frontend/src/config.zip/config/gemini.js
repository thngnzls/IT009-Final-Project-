const GEMINI_API_KEY = 'AIzaSyD9UC4upZy6m7dUv3uKt0lDRsjbLfhTT0o';
export default GEMINI_API_KEY;